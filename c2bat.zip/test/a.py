K='Disassembly of'
i='args'
h='instr'
g='addr'
c='\n'
G='final.bat'
b=','
a='x1'
F=print
E=range
D=open
U=len
P=int
N=''
import re as Q
L={'zero':'x0','ra':a,'sp':'x2','gp':'x3','tp':'x4','t0':'x5','t1':'x6','t2':'x7','s0':'x8','fp':'x8','s1':'x9','a0':'x10','a1':'x11','a2':'x12','a3':'x13','a4':'x14','a5':'x15','a6':'x16','a7':'x17','s2':'x18','s3':'x19','s4':'x20','s5':'x21','s6':'x22','s7':'x23','s8':'x24','s9':'x25','s10':'x26','s11':'x27','t3':'x28','t4':'x29','t5':'x30','t6':'x31'}
def O(reg):
	A=reg
	if not A:return N
	A=A.strip().rstrip(b)
	if A.startswith('x')and A[1:].isdigit():return A
	return L.get(A,A)
def u(line):
	C='^\\s*([0-9a-f]+):\\s+([0-9a-f]+)\\s+([\\w.]+)\\s*(.*)';B=Q.search(C,line)
	if not B:return
	D,H,E,A=B.groups();A=A.split('#')[0].split(';')[0].strip();F=[A.strip()for A in A.split(b)if A.strip()];G=[O(A)for A in F];return{g:P(D,16),h:E,i:G}
A=N
H=0
V=0
with D('out.asm','r')as M:
	A=list(M)
	for B in E(U(A)):
		if'<.text>'in A[B]:R=A[B].split()[0];H=P(R,16);F('start: '+str(H));B+=1;break
	A=A[B:]
	for B in E(U(A)):
		if K in A[B]:break
	for B in E(U(A)):
		if K in A[B]:break
	A=A[:B];A=N.join(A);F(U(A))
with D(G,'w')as C:C.write('@echo off\nsetlocal enabledelayedexpansion\ncall mem_init.bat\ngoto :INIT\n')
X=N
def S(line,is_last):
	t='lhu';s='xori';r='andi';q='lui';p='jalr';o='auipc';f='lbu';V=line;T='<';S='0x';R='(-?\\d+)\\((.*)\\)'
	if is_last:return'exit\n'
	Y=u(V)
	if not Y:return
	V=V.strip()
	if':'in V:j=V.split(':');Z=P(j[0].strip(),16);k=j[1].strip().split();D=k[1];A=N.join(k[2:]).split(b)
	D=Y[h];A=Y[i];d=Y[g];B=[f":l{d}"]
	if D=='jal':
		if U(A)==1:l=a;K=A[0]
		else:l=A[0];K=A[1]
		L=K.replace(S,N).split(T)[0].strip();M=P(L,16);v=d+4;B.append(f'set /a "{l}={v}"');B.append(f"goto :l{M}")
	elif D=='mul':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! * !{J}!"')
	elif D=='div':C,G,J=A[0],A[1],A[2];B.append(f'if "!{J}!"=="0" (set "{C}=0") else (set /a "{C}=!{G}! / !{J}!")')
	elif D=='rem':C,G,J=A[0],A[1],A[2];B.append(f'if "!{J}!"=="0" (set "{C}=0") else (set /a "{C}=!{G}! %% !{J}!")')
	elif D==o:C,E=A[0],A[1];B.append(f'set /a "{C}={Z} + ({E} << 12)"')
	elif D==p:
		if U(A)>1:C=A[0];e=A[1]
		else:C=a;e=A[0]
		I=Q.search(R,e)
		if I:E=I.group(1);G=O(I.group(2))
		else:E='0';G=O(e)
		B.append(f'set /a "{C}={Z} + 4"');B.append(f'set /a "target=(!{G}! + {E}) & ~1"');B.append(f"goto :l!target!")
	elif D==p:
		C=A[0];I=Q.match(R,A[1])
		if I:E,G=I.groups();G=O(G);B.append(f'set /a "{C}={Z} + 4"');B.append(f'set /a "target=(!{G}! + {E}) & ~1"');B.append(f"goto :l!target!")
	elif D==q:C,E=A[0],A[1];B.append(f'set /a "{C}={E} << 12"')
	elif D==o:C,E=A[0],A[1];B.append(f'set /a "{C}={Z} + ({E} << 12)"')
	elif D in['slt','slti']:C,G,J=A[0],A[1],A[2];B.append(f"if !{G}! lss !{J}! (set {C}=1) else (set {C}=0)")
	elif D=='ori':C,G,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! | {E}"')
	elif D==r:C,G,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! & {E}"')
	elif D==s:C,G,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! ^ {E}"')
	elif D=='lb':
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'if "!mem%addr%!"=="" (set "val=0") else (set "val=!mem%addr%!")');B.append(f'if !val! geq 128 (set /a "{C}=!val! | 0xFFFFFF00") else (set /a "{C}=!val!")')
	elif D==f:
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'if "!mem%addr%!"=="" (set "{C}=0") else (set "{C}=!mem%addr%!")')
	elif D==f:
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'if "!mem%addr%!"=="" (set "{C}=0") else (set "{C}=!mem%addr%!")')
	elif D=='lw':
		C=A[0];I=Q.match(R,A[1])
		if I:
			E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}", "a1=addr+1", "a2=addr+2", "a3=addr+3"')
			for(m,n)in enumerate(['%addr%','%a1%','%a2%','%a3%']):B.append(f'if "!mem{n}!"=="" (set "v{m}=0") else (set "v{m}=!mem{n}!")')
			B.append(f'set /a "{C}=v0 | (v1 << 8) | (v2 << 16) | (v3 << 24)"')
	elif D==t:
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}", "a1=addr+1"');B.append(f'if "!mem%addr%!"=="" (set "v0=0") else (set "v0=!mem%addr%!")');B.append(f'if "!mem%a1%!"=="" (set "v1=0") else (set "v1=!mem%a1%!")');B.append(f'set /a "{C}=v0 | (v1 << 8)"')
	elif D=='lh':
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}", "a1=addr+1"');B.append(f'if "!mem%addr%!"=="" (set "v0=0") else (set "v0=!mem%addr%!")');B.append(f'if "!mem%a1%!"=="" (set "v1=0") else (set "v1=!mem%a1%!")');B.append(f'set /a "val=v0 | (v1 << 8)"');B.append(f'if !val! GEQ 32768 (set /a "{C}=!val! | 0xFFFF0000") else (set /a "{C}=!val!")')
	elif D=='not':C,H=A[0],A[1];B.append(f'set /a "{C}=~!{H}!"')
	elif D=='bge':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{G}! geq !{J}! goto :l{M}")
	elif D=='bltz':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! lss 0 goto :l{M}")
	elif D=='li':C,E=A[0],A[1];B.append(f'set /a "{C}={E}"')
	elif D==f:
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "{C}=!mem%addr%!"')
	elif D=='srli':C,H,W=A[0],A[1],A[2];B.append(f'set /a "{C}=(!{H}! >> {W}) & (0x7FFFFFFF >> ({W}-1))"')
	elif D=='blez':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! leq 0 goto :l{M}")
	elif D=='bnez':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! neq 0 goto :l{M}")
	elif D=='mv':C,H=A[0],A[1];B.append(f'set /a "{C}=!{H}!"')
	elif D==s:C,H,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! ^ {E}"')
	elif D=='blt':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{G}! lss !{J}! goto :l{M}")
	elif D=='beqz':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! equ 0 goto :l{M}")
	elif D==r:C,H,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! & {E}"')
	elif D=='ret':B.append('goto :l!x1!')
	elif D=='lw':
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "a1=addr+1", "a2=addr+2", "a3=addr+3"');B.append(f'set /a "{C}=!mem%addr%! | (!mem%a1%! << 8) | (!mem%a2%! << 16) | (!mem%a3%! << 24)"')
	elif D==q:C,E=A[0],A[1];B.append(f'set /a "{C}={E} << 12"')
	elif D=='and':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! & !{J}!"')
	elif D=='bgez':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! geq 0 goto :l{M}")
	elif D=='xor':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! ^ !{J}!"')
	elif D=='beq':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{G}! equ !{J}! goto :l{M}")
	elif D=='or':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! | !{J}!"')
	elif D=='bne':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{G}! neq !{J}! goto :l{M}")
	elif D=='sub':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! - !{J}!"')
	elif D=='sb':
		H=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "b0=!{H}! & 0xFF"');B.append(f'set "mem!addr!=!b0!"')
	elif D=='zext.b':C,H=A[0],A[1];B.append(f'set /a "{C}=!{H}! & 0xFF"')
	elif D=='j':K=A[0];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"goto :l{M}")
	elif D=='sh':
		H=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "b0=!{H}! & 0xFF", "b1=(!{H}! >> 8) & 0xFF"');B.append(f'set "mem!addr!=!b0!"');B.append(f'set /a "a1=addr+1" & set "mem!a1!=!b1!"')
	elif D==t:
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "a1=addr+1"');B.append(f'set /a "{C}=!mem%addr%! | (!mem%a1%! << 8)"')
	elif D=='neg':C,H=A[0],A[1];B.append(f'set /a "{C}=-!{H}!"')
	elif D=='jr':H=A[0];B.append(f"goto :l!{H}!")
	elif D=='sra':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! >> !{J}!"')
	elif D=='sltu':C,G,J=A[0],A[1],A[2];B.append(f'set /a "t1=!{G}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! lss !t2! (set {C}=1) else (set {C}=0)")
	elif D=='add':C,G,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! + !{J}!"')
	elif D=='snez':C,H=A[0],A[1];B.append(f"if !{H}! neq 0 (set {C}=1) else (set {C}=0)")
	elif D=='lh':
		C=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}", "a1=addr+1"');B.append(f'set /a "val=!mem%addr%! | (!mem%a1%! << 8)"');B.append(f'if !val! GEQ 32768 (set /a "{C}=!val! | 0xFFFF0000") else (set /a "{C}=!val!")')
	elif D=='bgtz':H,K=A[0],A[1];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f"if !{H}! gtr 0 goto :l{M}")
	elif D=='bltu':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f'set /a "t1=!{G}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! lss !t2! goto :l{M}")
	elif D=='bgeu':G,J,K=A[0],A[1],A[2];L=K.replace(S,N).split(T)[0].strip();M=P(L,16);B.append(f'set /a "t1=!{G}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! geq !t2! goto :l{M}")
	elif D=='srl':C,G,J=A[0],A[1],A[2];B.append(f'set /a "shamt=!{J}! & 31"');B.append(f'set /a "{C}=(!{G}! >> !shamt!) & (0x7FFFFFFF >> (!shamt!-1))"')
	elif D=='nop':B.append(':: nop')
	elif D=='slli':C,H,W=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! << {W}"')
	elif D=='seqz':C,H=A[0],A[1];B.append(f"if !{H}! equ 0 (set {C}=1) else (set {C}=0)")
	elif D=='srai':C,H,W=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! >> {W}"')
	elif D=='addi':C,H,E=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! + {E}"')
	elif D=='sll':C,G,J=A[0],A[1],A[2];B.append(f'set /a "shamt=!{J}! & 31"');B.append(f'set /a "{C}=!{G}! << !shamt!"')
	elif D=='sw':
		H=A[0];I=Q.match(R,A[1])
		if I:E,F=I.groups();F=O(F);B.append(f'set /a "addr=!{F}! + {E}"');B.append(f'set /a "b0=!{H}! & 0xFF", "b1=(!{H}! >> 8) & 0xFF", "b2=(!{H}! >> 16) & 0xFF", "b3=(!{H}! >> 24) & 0xFF"');B.append(f'set "mem!addr!=!b0!"');B.append(f'set /a "a1=addr+1, a2=addr+2, a3=addr+3"');B.append(f'set "mem!a1!=!b1!" & set "mem!a2!=!b2!" & set "mem!a3!=!b3!"')
	else:return f"Implement {D} at {hex(d)}\n"
	if'# 0x12345678'in V:B.append('echo !x10!\n')
	if'# 0x87654321'in V:global X;X=B[0]
	B.append('set x0=0\n');return c.join(B)
I=0
for T in A.strip().split(c):
	J=S(T,I==U(A.strip().split(c))-1);I+=1
	if J:
		with D(G,'a')as C:C.write(J)
F('entry: '+X)
with D(G,'a')as C:C.write(f":INIT\ngoto {X}\n")
