K='Disassembly of'
g='args'
f='instr'
e='addr'
b='\n'
G='final.bat'
a=','
F=print
E=range
D=open
V=len
O=int
N=''
import re as P
L={'zero':'x0','ra':'x1','sp':'x2','gp':'x3','tp':'x4','t0':'x5','t1':'x6','t2':'x7','s0':'x8','fp':'x8','s1':'x9','a0':'x10','a1':'x11','a2':'x12','a3':'x13','a4':'x14','a5':'x15','a6':'x16','a7':'x17','s2':'x18','s3':'x19','s4':'x20','s5':'x21','s6':'x22','s7':'x23','s8':'x24','s9':'x25','s10':'x26','s11':'x27','t3':'x28','t4':'x29','t5':'x30','t6':'x31'}
def Q(reg):
	A=reg
	if not A:return N
	A=A.strip().rstrip(a)
	if A.startswith('x')and A[1:].isdigit():return A
	return L.get(A,A)
def s(line):
	C='^\\s*([0-9a-f]+):\\s+([0-9a-f]+)\\s+([\\w.]+)\\s*(.*)';B=P.search(C,line)
	if not B:return
	D,H,E,A=B.groups();A=A.split('#')[0].split(';')[0].strip();F=[A.strip()for A in A.split(a)if A.strip()];G=[Q(A)for A in F];return{e:O(D,16),f:E,g:G}
A=N
H=0
U=0
with D('out.asm','r')as M:
	A=list(M)
	for B in E(V(A)):
		if'<.text>'in A[B]:R=A[B].split()[0];H=O(R,16);F('start: '+str(H));B+=1;break
	A=A[B:]
	for B in E(V(A)):
		if K in A[B]:break
	for B in E(V(A)):
		if K in A[B]:break
	A=A[:B];A=N.join(A);F(V(A))
with D(G,'w')as C:C.write('@echo off\nsetlocal enabledelayedexpansion\ncall mem_init.bat\ngoto :INIT\n')
X=N
def S(line,is_last):
	r='lhu';q='xori';p='andi';o='lui';n='jalr';m='auipc';d='lbu';U=line;T='(-?\\d+)\\((.*)\\)';S='<';R='0x'
	if is_last:return'exit\n'
	Y=s(U)
	if not Y:return
	U=U.strip()
	if':'in U:h=U.split(':');Z=O(h[0].strip(),16);i=h[1].strip().split();D=i[1];A=N.join(i[2:]).split(a)
	D=Y[f];A=Y[g];c=Y[e];B=[f":l{c}"]
	if D=='jal':
		if V(A)==1:j='x1';K=A[0]
		else:j=A[0];K=A[1]
		L=K.replace(R,N).split(S)[0].strip();M=O(L,16);t=c+4;B.append(f'set /a "{j}={t}"');B.append(f"goto :l{M}")
	elif D==m:C,F=A[0],A[1];B.append(f'set /a "{C}={Z} + ({F} << 12)"')
	elif D==n:C=A[0];B.append(f'set /a "{C}={Z} + 4"');B.append(f'set /a "target=(!{H}! + {F}) & ~1"');B.append(f"goto :l!target!")
	elif D==n:
		C=A[0];I=P.match(T,A[1])
		if I:F,H=I.groups();H=Q(H);B.append(f'set /a "{C}={Z} + 4"');B.append(f'set /a "target=(!{H}! + {F}) & ~1"');B.append(f"goto :l!target!")
	elif D==o:C,F=A[0],A[1];B.append(f'set /a "{C}={F} << 12"')
	elif D==m:C,F=A[0],A[1];B.append(f'set /a "{C}={Z} + ({F} << 12)"')
	elif D in['slt','slti']:C,H,J=A[0],A[1],A[2];B.append(f"if !{H}! lss !{J}! (set {C}=1) else (set {C}=0)")
	elif D=='ori':C,H,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! | {F}"')
	elif D==p:C,H,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! & {F}"')
	elif D==q:C,H,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! ^ {F}"')
	elif D=='lb':
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'if "!mem%addr%!"=="" (set "val=0") else (set "val=!mem%addr%!")');B.append(f'if !val! geq 128 (set /a "{C}=!val! | 0xFFFFFF00") else (set /a "{C}=!val!")')
	elif D==d:
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'if "!mem%addr%!"=="" (set "{C}=0") else (set "{C}=!mem%addr%!")')
	elif D==d:
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'if "!mem%addr%!"=="" (set "{C}=0") else (set "{C}=!mem%addr%!")')
	elif D=='lw':
		C=A[0];I=P.match(T,A[1])
		if I:
			F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}", "a1=addr+1", "a2=addr+2", "a3=addr+3"')
			for(k,l)in enumerate(['%addr%','%a1%','%a2%','%a3%']):B.append(f'if "!mem{l}!"=="" (set "v{k}=0") else (set "v{k}=!mem{l}!")')
			B.append(f'set /a "{C}=v0 | (v1 << 8) | (v2 << 16) | (v3 << 24)"')
	elif D==r:
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}", "a1=addr+1"');B.append(f'if "!mem%addr%!"=="" (set "v0=0") else (set "v0=!mem%addr%!")');B.append(f'if "!mem%a1%!"=="" (set "v1=0") else (set "v1=!mem%a1%!")');B.append(f'set /a "{C}=v0 | (v1 << 8)"')
	elif D=='lh':
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}", "a1=addr+1"');B.append(f'if "!mem%addr%!"=="" (set "v0=0") else (set "v0=!mem%addr%!")');B.append(f'if "!mem%a1%!"=="" (set "v1=0") else (set "v1=!mem%a1%!")');B.append(f'set /a "val=v0 | (v1 << 8)"');B.append(f'if !val! GEQ 32768 (set /a "{C}=!val! | 0xFFFF0000") else (set /a "{C}=!val!")')
	elif D=='not':C,G=A[0],A[1];B.append(f'set /a "{C}=~!{G}!"')
	elif D=='bge':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{H}! geq !{J}! goto :l{M}")
	elif D=='bltz':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! lss 0 goto :l{M}")
	elif D=='li':C,F=A[0],A[1];B.append(f'set /a "{C}={F}"')
	elif D==d:
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "{C}=!mem%addr%!"')
	elif D=='srli':C,G,W=A[0],A[1],A[2];B.append(f'set /a "{C}=(!{G}! >> {W}) & (0x7FFFFFFF >> ({W}-1))"')
	elif D=='blez':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! leq 0 goto :l{M}")
	elif D=='bnez':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! neq 0 goto :l{M}")
	elif D=='mv':C,G=A[0],A[1];B.append(f'set /a "{C}=!{G}!"')
	elif D==q:C,G,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! ^ {F}"')
	elif D=='blt':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{H}! lss !{J}! goto :l{M}")
	elif D=='beqz':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! equ 0 goto :l{M}")
	elif D==p:C,G,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! & {F}"')
	elif D=='ret':B.append('goto :l!x1!')
	elif D=='lw':
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "a1=addr+1", "a2=addr+2", "a3=addr+3"');B.append(f'set /a "{C}=!mem%addr%! | (!mem%a1%! << 8) | (!mem%a2%! << 16) | (!mem%a3%! << 24)"')
	elif D==o:C,F=A[0],A[1];B.append(f'set /a "{C}={F} << 12"')
	elif D=='and':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! & !{J}!"')
	elif D=='bgez':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! geq 0 goto :l{M}")
	elif D=='xor':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! ^ !{J}!"')
	elif D=='beq':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{H}! equ !{J}! goto :l{M}")
	elif D=='or':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! | !{J}!"')
	elif D=='bne':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{H}! neq !{J}! goto :l{M}")
	elif D=='sub':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! - !{J}!"')
	elif D=='sb':
		G=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "b0=!{G}! & 0xFF"');B.append(f'set "mem!addr!=!b0!"')
	elif D=='zext.b':C,G=A[0],A[1];B.append(f'set /a "{C}=!{G}! & 0xFF"')
	elif D=='j':K=A[0];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"goto :l{M}")
	elif D=='sh':
		G=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "b0=!{G}! & 0xFF", "b1=(!{G}! >> 8) & 0xFF"');B.append(f'set "mem!addr!=!b0!"');B.append(f'set /a "a1=addr+1" & set "mem!a1!=!b1!"')
	elif D==r:
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "a1=addr+1"');B.append(f'set /a "{C}=!mem%addr%! | (!mem%a1%! << 8)"')
	elif D=='neg':C,G=A[0],A[1];B.append(f'set /a "{C}=-!{G}!"')
	elif D=='jr':G=A[0];B.append(f"goto :l!{G}!")
	elif D=='sra':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! >> !{J}!"')
	elif D=='sltu':C,H,J=A[0],A[1],A[2];B.append(f'set /a "t1=!{H}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! lss !t2! (set {C}=1) else (set {C}=0)")
	elif D=='add':C,H,J=A[0],A[1],A[2];B.append(f'set /a "{C}=!{H}! + !{J}!"')
	elif D=='snez':C,G=A[0],A[1];B.append(f"if !{G}! neq 0 (set {C}=1) else (set {C}=0)")
	elif D=='lh':
		C=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}", "a1=addr+1"');B.append(f'set /a "val=!mem%addr%! | (!mem%a1%! << 8)"');B.append(f'if !val! GEQ 32768 (set /a "{C}=!val! | 0xFFFF0000") else (set /a "{C}=!val!")')
	elif D=='bgtz':G,K=A[0],A[1];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f"if !{G}! gtr 0 goto :l{M}")
	elif D=='bltu':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f'set /a "t1=!{H}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! lss !t2! goto :l{M}")
	elif D=='bgeu':H,J,K=A[0],A[1],A[2];L=K.replace(R,N).split(S)[0].strip();M=O(L,16);B.append(f'set /a "t1=!{H}! + 0x80000000", "t2=!{J}! + 0x80000000"');B.append(f"if !t1! geq !t2! goto :l{M}")
	elif D=='srl':C,H,J=A[0],A[1],A[2];B.append(f'set /a "shamt=!{J}! & 31"');B.append(f'set /a "{C}=(!{H}! >> !shamt!) & (0x7FFFFFFF >> (!shamt!-1))"')
	elif D=='nop':B.append(':: nop')
	elif D=='slli':C,G,W=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! << {W}"')
	elif D=='seqz':C,G=A[0],A[1];B.append(f"if !{G}! equ 0 (set {C}=1) else (set {C}=0)")
	elif D=='srai':C,G,W=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! >> {W}"')
	elif D=='addi':C,G,F=A[0],A[1],A[2];B.append(f'set /a "{C}=!{G}! + {F}"')
	elif D=='sll':C,H,J=A[0],A[1],A[2];B.append(f'set /a "shamt=!{J}! & 31"');B.append(f'set /a "{C}=!{H}! << !shamt!"')
	elif D=='sw':
		G=A[0];I=P.match(T,A[1])
		if I:F,E=I.groups();E=Q(E);B.append(f'set /a "addr=!{E}! + {F}"');B.append(f'set /a "b0=!{G}! & 0xFF", "b1=(!{G}! >> 8) & 0xFF", "b2=(!{G}! >> 16) & 0xFF", "b3=(!{G}! >> 24) & 0xFF"');B.append(f'set "mem!addr!=!b0!"');B.append(f'set /a "a1=addr+1, a2=addr+2, a3=addr+3"');B.append(f'set "mem!a1!=!b1!" & set "mem!a2!=!b2!" & set "mem!a3!=!b3!"')
	else:return f"Implement {D} at {hex(c)}\n"
	if'# 0x12345678'in U:B.append('echo !x10!\n')
	if'# 0x87654321'in U:global X;X=B[0]
	B.append('set x0=0\n');return b.join(B)
I=0
for T in A.strip().split(b):
	J=S(T,I==V(A.strip().split(b))-1);I+=1
	if J:
		with D(G,'a')as C:C.write(J)
F('entry: '+X)
with D(G,'a')as C:C.write(f":INIT\ngoto {X}\n")
