J='vma'
I='size'
H='.text'
E='offset'
D='name'
C=print
A=int
import subprocess as L,re,os
def N(elf_path):
	try:M=L.check_output(['riscv64-unknown-elf-objdump','-h',elf_path],universal_newlines=True)
	except Exception as N:C(f"error: {N}");return[]
	B=[];O=re.compile('^\\s*\\d+\\s+(\\.\\S+)\\s+([0-9a-fA-F]+)\\s+([0-9a-fA-F]+)\\s+[0-9a-fA-F]+\\s+([0-9a-fA-F]+)')
	for P in M.splitlines():
		F=O.match(P)
		if F:
			G,K,Q,R=F.groups()
			if A(K,16)>0 and G in[H,'.data','.rodata','.sdata']:B.append({D:G,I:A(K,16),J:A(Q,16),E:A(R,16)})
	return B
def B(elf_path,output_path='mem_init.bat'):
	L=output_path;K=elf_path;F=N(K)
	if not F:C('error');return
	with open(K,'rb')as A:O=A.read()
	with open(L,'w')as A:
		A.write('@echo off\n')
		for G in range(32):A.write(f"set x{G}=0\n")
		A.write('set x2=131072\n');A.write('\n')
		for B in F:
			if H in B[D]:continue
			A.write(f"");P=O[B[E]:B[E]+B[I]]
			for(G,M)in enumerate(P):
				if M!=0:Q=B[J]+G;A.write(f'set "mem{Q}={M}"\n')
	C(f"mem mapped")
if __name__=='__main__':B('main')
