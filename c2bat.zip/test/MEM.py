J='vma'
I='size'
H='name'
G='.text'
F='error'
D='offset'
C=print
A=int
import subprocess as M,re,os
def N(elf_path):
	try:N=M.check_output(['riscv64-unknown-elf-objdump','-h',elf_path],universal_newlines=True)
	except Exception as S:C(F);return[]
	B=[];O=re.compile('^\\s*\\d+\\s+(\\.\\S+)\\s+([0-9a-fA-F]+)\\s+([0-9a-fA-F]+)\\s+[0-9a-fA-F]+\\s+([0-9a-fA-F]+)')
	for P in N.splitlines():
		E=O.match(P)
		if E:
			K,L,Q,R=E.groups()
			if A(L,16)>0 and K in[G,'.data','.rodata','.sdata']:B.append({H:K,I:A(L,16),J:A(Q,16),D:A(R,16)})
	return B
def B(elf_path,output_path='mem_init.bat'):
	K=elf_path;L=N(K)
	if not L:C(F);return
	with open(K,'rb')as A:O=A.read()
	with open(output_path,'w')as A:
		A.write('@echo off\n')
		for E in range(32):A.write(f"set x{E}=0\n")
		A.write('set x2=10000000\n')
		for B in L:
			if G in B[H]:continue
			P=O[B[D]:B[D]+B[I]]
			for(E,M)in enumerate(P):
				if M!=0:Q=B[J]+E;A.write(f'set "mem{Q}={M}"\n')
	C(f"mem mapped")
if __name__=='__main__':B('main')
