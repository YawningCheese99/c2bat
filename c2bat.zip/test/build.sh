riscv64-unknown-elf-gcc test.c -o main   -march=rv32i -mabi=ilp32   -ffreestanding -nostdlib -static -lgcc -s
riscv64-linux-gnu-objdump -D main > out.asm
python a.py
python MEM.py