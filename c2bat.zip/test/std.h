#define ENTRY int s = 0x87654321;
void puti(int c) {
    int i = 0x12345678;
}