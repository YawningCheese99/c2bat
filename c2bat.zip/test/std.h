#define ENTRY int s = 0x87654321; asm volatile(".option push\n.option norelax\nla gp, __global_pointer$\n.option pop");
void puti(int c) {
    int i = 0x12345678;
}
