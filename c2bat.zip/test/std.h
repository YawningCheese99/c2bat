#define ENTRY asm("ecall"); asm volatile(".option push\n.option norelax\nla gp, __global_pointer$\n.option pop");

void (*puti)(int i) = 100000000;
void (*puts)(char* s) = 200000000;
int (*poparg)(int a) = 300000000;