:: puti
:l100000000
echo !x10!
goto :l!x1!
:: puts
:l200000000
set temp=%x10%
set str=
:s1
if !mem%temp%! equ 59 goto :s2
if !mem%temp%! equ 32 set "str=%str% "
if !mem%temp%! equ 97 set str=%str%a
if !mem%temp%! equ 98 set str=%str%b
if !mem%temp%! equ 99 set str=%str%c
if !mem%temp%! equ 100 set str=%str%d
if !mem%temp%! equ 101 set str=%str%e
if !mem%temp%! equ 102 set str=%str%f
if !mem%temp%! equ 103 set str=%str%g
if !mem%temp%! equ 104 set str=%str%h
if !mem%temp%! equ 105 set str=%str%i
if !mem%temp%! equ 106 set str=%str%j
if !mem%temp%! equ 107 set str=%str%k
if !mem%temp%! equ 108 set str=%str%l
if !mem%temp%! equ 109 set str=%str%m
if !mem%temp%! equ 110 set str=%str%n
if !mem%temp%! equ 111 set str=%str%o
if !mem%temp%! equ 112 set str=%str%p
if !mem%temp%! equ 113 set str=%str%q
if !mem%temp%! equ 114 set str=%str%r
if !mem%temp%! equ 115 set str=%str%s
if !mem%temp%! equ 116 set str=%str%t
if !mem%temp%! equ 117 set str=%str%u
if !mem%temp%! equ 118 set str=%str%v
if !mem%temp%! equ 119 set str=%str%w
if !mem%temp%! equ 120 set str=%str%x
if !mem%temp%! equ 121 set str=%str%y
if !mem%temp%! equ 122 set str=%str%z

if !mem%temp%! equ 65 set str=%str%A
if !mem%temp%! equ 66 set str=%str%B
if !mem%temp%! equ 67 set str=%str%C
if !mem%temp%! equ 68 set str=%str%D
if !mem%temp%! equ 69 set str=%str%E
if !mem%temp%! equ 70 set str=%str%F
if !mem%temp%! equ 71 set str=%str%G
if !mem%temp%! equ 72 set str=%str%H
if !mem%temp%! equ 73 set str=%str%I
if !mem%temp%! equ 74 set str=%str%J
if !mem%temp%! equ 75 set str=%str%K
if !mem%temp%! equ 76 set str=%str%L
if !mem%temp%! equ 77 set str=%str%M
if !mem%temp%! equ 78 set str=%str%N
if !mem%temp%! equ 79 set str=%str%O
if !mem%temp%! equ 80 set str=%str%P
if !mem%temp%! equ 81 set str=%str%Q
if !mem%temp%! equ 82 set str=%str%R
if !mem%temp%! equ 83 set str=%str%S
if !mem%temp%! equ 84 set str=%str%T
if !mem%temp%! equ 85 set str=%str%U
if !mem%temp%! equ 86 set str=%str%V
if !mem%temp%! equ 87 set str=%str%W
if !mem%temp%! equ 88 set str=%str%X
if !mem%temp%! equ 89 set str=%str%Y
if !mem%temp%! equ 90 set str=%str%Z

if !mem%temp%! equ 48 set str=%str%0
if !mem%temp%! equ 49 set str=%str%1
if !mem%temp%! equ 50 set str=%str%2
if !mem%temp%! equ 51 set str=%str%3
if !mem%temp%! equ 52 set str=%str%4
if !mem%temp%! equ 53 set str=%str%5
if !mem%temp%! equ 54 set str=%str%6
if !mem%temp%! equ 55 set str=%str%7
if !mem%temp%! equ 56 set str=%str%8
if !mem%temp%! equ 57 set str=%str%9

set /a temp+=1
goto :s1
:s2
echo %str%
goto :l!x1!

:: poparg
:l300000000
call set "x10=%%%x10%"
goto :l!x1!