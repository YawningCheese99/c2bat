#include "std.h"

unsigned int data[] = {
    'a', 'a', 'a', 20, 'a', 'a', 'a', 'a', 'b', 'c'
};

void calc_with_ptrs(int* a, int* b, int* c) {
    *c = *a;
    *a = *a + *b;
    *b = *c;
}

int fib(int count) {
    int a = 1;
    int b = 0;
    int c = 0;

    for (int i = 0; i < count-1; i++) {
    calc_with_ptrs(&a, &b, &c);
    }

    return a;
}

int main() {
    ENTRY
    puti(fib(data[3]));

    return 0;
} 