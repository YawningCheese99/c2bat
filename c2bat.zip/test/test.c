#include "std.h"

typedef struct {
    int i;
} S;

S st;

unsigned int data[] = {
    'a', 'a', 'a', 20, 'a', 'a', 'a', 'a', 'b', 'c'
};

int add(int a, int b) {
    return a + b;
}

int fact(int n) {
    if (n <= 1) return 1;
    return n * fact(n - 1);
}

int (*add_ptr)(int, int) = add;

void calc_with_ptrs(int* a, int* b, int* c) {
    *c = *a;
    *a = add_ptr(*a, *b);
    *b = *c;
}

int fib(int count) {
    int a = 1;
    int b = 0;
    int c = 0;

    for (int i = 0; i < count-1; i++) {
    calc_with_ptrs(&a, &b, &c);
    }

    return a;
}

int main() {
    ENTRY
    st.i = 89;
    puti(st.i);
    puti(fib(data[3]));

    switch (2) {
        case 1:
            puti(1);
            break;
        case 2:
            puti(2);
            break;
        default:
            puti(0);
    }

    puti(99999999);

    if (0 == 1) {
        puti(0);
    }

    if (1 == 1) {
        puti(1);
    }

    puti(fact(6));


    int *ptr = 0;
    if (ptr != 0 && *ptr == 10) { 
        puti(1);
    } else {
        puti(42);
    }

    int matrix[2][2] = {{1, 2}, {3, 4}};
    int *p = &matrix[0][0];
    puti(*(p + 3));

    return 0;
} 
